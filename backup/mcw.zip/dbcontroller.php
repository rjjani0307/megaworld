<?php
class DBController {
	private $host = "mysql.hostinger.in";
	private $user = "u795941923_mcw";
	private $password = "Sunay@9998";
	private $database = "u795941923_mcw";
	private $conn;
	
// 	private $host = "localhost";
// 	private $user = "root";
// 	private $password = "";
// 	private $database = "mcw";
	//private $conn;

	function __construct() {
		$this->conn = $this->connectDB();
	}
	
	function connectDB() {
		$conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
		return $conn;
	}
	
	function runQuery($query) {
		$result = mysqli_query($this->conn,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = mysqli_query($this->conn,$query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}
}
?>