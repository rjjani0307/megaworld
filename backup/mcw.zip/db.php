

<?php

// Create connection
$conn = new mysqli('mysql.hostinger.in', 'u795941923_mcw','Sunay@9998','u795941923_mcw');
$con = mysqli_connect('mysql.hostinger.in', 'u795941923_mcw','Sunay@9998');
mysqli_select_db($con, 'u795941923_mcw');


//$conn = new mysqli('localhost', 'root','','mcw');
//$con = mysqli_connect('localhost', 'root','');
//mysqli_select_db($con, 'mcw');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>