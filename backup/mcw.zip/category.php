<?php
include "db.php";
session_start();
     if(isset($_SESSION['Filter'])){ $filter = $_SESSION['Filter']; }else{ $filter = " "; }
    
    $whr = ""; $a = ""; $b = ""; $c = ""; $d = ""; $e = "";
    if(isset($_REQUEST['cat'])){
         $cat = $_REQUEST['cat'];
       
         $view="select DISTINCT two from category WHERE one = '$cat'";   
         
          if(isset($_REQUEST['catm'])){
                 $catm = $_REQUEST['catm'];
                 $view="select DISTINCT  three from category WHERE two = '$catm'"; 
         }
            if(isset($_REQUEST['cats'])){
                     $cats = $_REQUEST['cats'];
                     $view="select DISTINCT  three from category WHERE three = '$cats'";     
                
            }
         }
         
    if(isset($_POST["select"])){  $_SESSION["Filter"] = $_POST["select"]; 
     ?>    <script>  window.location.replace(window.location.href); </script> <?php }
     
     if(isset($_SESSION["Filter"])){
      $filt = $_SESSION["Filter"];
        if($filt == 'AZ'){
            $filt = 'ORDER BY name ASC'; 
            $a = 'selected';
        }elseif($filt == 'ZA'){
             $filt = 'ORDER BY name DESC';
             $b = 'selected';
        }elseif($filt == 'LH'){
             $filt = 'ORDER BY price ASC';
             $c = 'selected';
        }elseif($filt == 'HL'){
             $filt = 'ORDER BY price DESC';
             $d = 'selected';
        }else{
            $filt = 'ORDER BY id DESC';
            $e = 'selected';
        }    
      }else{
            $filt = 'ORDER BY id DESC';
            $e = 'selected';
        }
    
?>                      
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title -->
     <title>MCW - Mega Computer World</title>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="author" content="spacingtech_webify">
    <!-- favicon -->
    <link rel="shortcut icon" type="image/favicon" href="image/mcw_r.jpeg">
    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- simple-line icon -->
    <link rel="stylesheet" type="text/css" href="css/simple-line-icons.css">
    <!-- font-awesome icon -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="css/themify-icons.css">
    <!-- ion icon -->
    <link rel="stylesheet" type="text/css" href="css/ionicons.min.css">
    <!-- owl slider -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <!-- swiper -->
    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
    <!-- animation -->
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <!-- style --> 
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body class="home-1">
  <?php include "header.php";  ?>
        
          <!-- breadcrumb start -->
      <!--   <section class="about-breadcrumb">
            <div class="about-back section-tb-padding" style="background-image: url(image/about-image.jpg)">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="about-l">
                                <ul class="about-link">
                                    <li class="go-home"><a href="index1.html">Home</a></li>
                                    <li class="about-p"><span>Category</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        breadcrumb end -->

      <section class="section-t-padding" style="background-color: #f2f2f2">
        <div class="container">
            <div class="row">
                <div class="col"> 
                    <div class="track-area">
                           <div class="track-price">
                            <ul class="track-order">
                                <li>
                            <h4><?php  
                            if(isset($_REQUEST['cat'])){
                                 echo $_REQUEST['cat'] . " &nbsp; > &nbsp;";
                             }  ?> <?php  
                            if(isset($_REQUEST['cat']) && !empty($_REQUEST['catm'])){
                                 echo $_REQUEST['catm'];
                             }  ?>  <?php  
                            if(isset($_REQUEST['catm']) && isset($_REQUEST['cat']) && !empty($_REQUEST['cats'])){
                                        echo "&nbsp; > &nbsp;" . $_REQUEST['cats'];
                                         $whr = "WHERE m_ctg = '" . $cat . "' AND c_ctg = '" . $catm. "' AND s_ctg = '" . $cats . "'";
                                     }   ?></h4>
                                </li>
                            </ul>
                        </div>
                        <div class="track-main" style="border-top: 1px solid #212529">
                          <div class="track">
                            <?php
                             
                        if(isset($_REQUEST['cat']) && !isset($_REQUEST['catm'])){
                                $whr = "WHERE m_ctg = '" . $cat . "'";
                               
                          $view="select DISTINCT two from category WHERE one = '$cat'";
                            $exe_view=mysqli_query($conn, $view);
                              while($results=mysqli_fetch_array($exe_view)){ ?>
                                <div class="step">
                                 <span class="text"><a href="category.php?cat=<?php echo $_REQUEST['cat']; ?>&catm=<?php echo $results['two']; ?>">
                                        <?php echo $results['two']; ?></a></span>
                                </div>
                                <?php }  }   
                                 
                                if(isset($_REQUEST['catm']) && isset($_REQUEST['cat']) && empty($_REQUEST['cats'])){ 
                                  $catm = $_REQUEST['catm'];
                                  $whr = "WHERE m_ctg = '" . $cat . "' AND c_ctg = '" . $catm . "'";
                                 $view="select DISTINCT  three from category WHERE two = '$catm'";  
                                $exe_view=mysqli_query($conn, $view);
                               while($results=mysqli_fetch_array($exe_view)){ ?>
                                <div class="step">
                                 <span class="text"><a href="category.php?cat=<?php echo $_REQUEST['cat']; ?>&catm=<?php echo $_REQUEST['catm']; ?>&cats=<?php echo $results['three']; ?>">
                                        <?php echo $results['three']; ?></a></span>
                                </div>
                                <?php }    }         ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- grid-list start -->
    <section class="section-b-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 section-t-padding">
                    <div class="all-filter">
                        <div class="categories-page-filter">
                            <h4 class="filter-title">Categories</h4>
                            <a href="#category-filter" data-bs-toggle="collapse" class="filter-link"><span>Categories </span><i class="fa fa-angle-down"></i></a>
                            <ul class="all-option collapse" id="category-filter">
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Baker's rack <span class="grid-items">(4)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Bestseller<span class="grid-items">(6)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Breakfast <span class="grid-items">(8)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Dairy & chesse <span class="grid-items">(7)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Dairy & chesse <span class="grid-items">(3)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Deal collection <span class="grid-items">(10)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Dinner <span class="grid-items">(12)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Featured product <span class="grid-items">(11)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Fresh fruits <span class="grid-items">(16)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Fresh meat <span class="grid-items">(18)</span></a>
                                </li><li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Fresh vegetable <span class="grid-items">(16)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Green seafood <span class="grid-items">(12)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Lunch <span class="grid-items">(14)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">New product <span class="grid-items">(20)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Organic dryfruit <span class="grid-items">(21)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Organic juice <span class="grid-items">(23)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Organic wine <span class="grid-items">(17)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Sea & fish <span class="grid-items">(1)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Special product <span class="grid-items">(5)</span></a>
                                </li>
                                <li class="grid-list-option">
                                    <input type="checkbox">
                                    <a href="javascript:void(0)">Starters <span class="grid-items">(9)</span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-md-8 col-12">
                    <div class="grid-list-area">
                        <div class="grid-list-select">
                            <ul class="grid-list">
                                
                            </ul>
                            <ul class="grid-list-selector">
                                <li>
                                <form method="post" action="">  
                                 <label>Sort by</label>
							   	 <select class="selectpicker" name="select" onchange="doSelect(this)">
									<option value=" " <?php echo $e; ?>>Featured</option>
									<option value="AZ" <?php echo $a; ?>>A-Z</option>
									<option value="ZA" <?php echo $b; ?>>Z-A</option>
									<option value="LH" <?php echo $c; ?>>Price, low to high</option>
									<option value="HL" <?php echo $d; ?>>Price, high to low</option>
								</select>
							   </form>
                                </li>
                            </ul>
                        </div></div>
                        <div class="grid-list-area" id="postContent">
                        <div class="grid-pro">
                      <ul class="grid-product">
          <?php 
        // Include pagination library file 
       include_once 'Pagination.php'; 
        // Set some useful configuration 
       $filename = '&filename='.basename(__FILE__, '.php');
        $baseURL = 'prod_page.php?'.substr(strrchr(basename($_SERVER["REQUEST_URI"]), "?"), 1).$filename; 
        $limit = 1; 
        // Count of all records 
        $query   = $conn->query("SELECT COUNT(*) as rowNum FROM product $whr $filt"); 
        $result  = $query->fetch_assoc(); 
        $rowCount= $result['rowNum']; 
         
         
        // Initialize pagination class 
        $pagConfig = array( 
            'baseURL' => $baseURL, 
            'totalRows' => $rowCount, 
            'perPage' => $limit, 
            'contentDiv' => 'postContent' 
        ); 
        $pagination =  new Pagination($pagConfig); 
        // Fetch records based on the limit 
        $sql = "SELECT * FROM product " . $whr . " $filt LIMIT $limit";  
        $query = $conn->query("$sql"); 
        if($query->num_rows > 0){ 
        ?>
            <!-- Display posts list -->
            <?php while($rows = $query->fetch_assoc()){ ?>
                                <li class="grid-items">
                                    <div class="tred-pro">
                                        <div class="tr-pro-img">
                                            <a href="product-details.php?p_id=<?php echo $rows['p_id']; ?>">
                                                <img class="img-fluid" src="admin/products/<?php echo $rows['img1']; ?>" alt="pro-img1">
                                                <img class="img-fluid additional-image" src="admin/products/<?php echo $rows['img2']; ?>" alt="additional image" alt="additional image">
                                            </a>
                                        </div>

                                        <div class="pro-icn">
                                            <a href="wishlist.html" class="w-c-q-icn"><i class="fa fa-heart"></i></a>
                                            <a href="cart.html" class="w-c-q-icn"><i class="fa fa-shopping-bag"></i></a>
                                            <a href="javascript:void(0)"  class="w-c-q-icn" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-eye"></i></a>
                                        </div>
                                    </div>
                                    <div class="caption">
                                        <h3><a href="product-details.php?p_id=<?php echo $rows['p_id']; ?>"><?php echo $rows['name']; ?></a></h3>
                                        <!--<div class="rating">-->
                                        <!--    <i class="fa fa-star c-star"></i>-->
                                        <!--    <i class="fa fa-star c-star"></i>-->
                                        <!--    <i class="fa fa-star c-star"></i>-->
                                        <!--    <i class="fa fa-star-o"></i>-->
                                        <!--    <i class="fa fa-star-o"></i>-->
                                        <!--</div>-->
                                        <div class="pro-price">
                                            <span class="new-price">₹ <?php echo $rows['price']; ?> INR</span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                   
                                 <?php  }  ?>
                         
                        <?php echo $pagination->createLinks(); ?>
						
            <!-- Display pagination links -->
           
        <?php }else{  ?>
                 </div> 
  		    	 <div class="list-all-page">
                   <span class="page-title">No More Products</span>
					 </div>
            <?php 	 } ?>
                         

                </div>
            </div>
        </div>
    </section>
    <!-- grid-list start -->
    <!-- footer start -->
    <?php include "footer.php";  ?>
   
    <a href="javascript:void(0)" class="scroll" id="top">
        <span><i class="fa fa-angle-double-up"></i></span>
    </a>
    <!-- back to top end -->
    <div class="mm-fullscreen-bg"></div>
    <!-- jquery -->
    <script src="js/modernizr-2.8.3.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- popper -->
    <script src="js/popper.min.js"></script>
    <!-- fontawesome -->
    <script src="js/fontawesome.min.js"></script>
    <!-- owl carousal -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- swiper -->
    <script src="js/swiper.min.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>
	<script type="text/javascript">
        function doSelect(el){
        sel = el.options[el.selectedIndex].value;
        	if(sel == "-"){
        		alert("Please choose an option");
        	}
        	else{
        		el.form.submit();
        	}
        }
    </script>
</body>
</html>