<?php
  include "addtocart.php";
  include "db.php";

 if (!isset($_SESSION['mcw_useremail'])) { header("location:login.php");  }
 if (!isset($_SESSION["cart_item"])) { header("location:index.php");  }
 
  if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
    $product_name = ""; $product_code = ""; $product_qty = ""; 
    $product_price = ""; $product_img = ""; $product_id = "";
    
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["sell_price"];
        $pname  = $item['name'];
        $p_id  = $item['p_id'];
        $quantity  = $item['quantity'];
        $sell_price  = $item['sell_price'];
        $img1  = $item['img1'];
        $product_name .= ",".$pname;
        $product_id .= ",".$p_id;
        $product_qty .= ",".$quantity;
        $product_price .= ",".$item_price;
        $product_img .= ",".$img1;
        $total_quantity += $item["quantity"];
        $total_price += ($item["sell_price"]*$item["quantity"]);
    }
 
}   

 if(isset($_POST['checkout'])){
// Required field names
$required = array('name', 'email', 'phone', 'city', 'address', 'zip','scity','saddress','szip');

// Loop over field names, make sure each one exists and is not empty
$err = false;
foreach($required as $field) {
  if (empty($_POST[$field])) {
    $err = true;
  }
}

if ($err) {
 $error = "All Fields  Are Required";
} else {
         $today = date("Ymd");
         $rand = strtoupper(substr(uniqid(sha1(time())),0,4));
         $order_number = $today . $rand;
         $product_name = substr($product_name, 1);
         $product_id = substr($product_id, 1);
         $product_img = substr($product_img, 1);
         $product_qty = substr($product_qty, 1);
         $product_price = substr($product_price, 1); 
         $name = $_POST['name'];
         $email = $_POST['email'];
         $phone = $_POST['phone'];
         $city = $_POST['city'];
         $address = $_POST['address'];
         $zip = $_POST['zip'];
         $scity = $_POST['scity'];
         $saddress = $_POST['saddress'];
         $szip = $_POST['szip'];

     $query = "INSERT INTO `order`(`order_number`, `product_code`, `product_img`, `product_name`, `quantity`, `total_qty`, `price`,`total_amount`, `user_id`, `user_name`, `email`, `number`, `city`, `address`, `zip`, `status`, `ord_date`, `ord_month`) VALUES ('$order_number','$product_id','$product_img','$product_name','$product_qty','$total_quantity','$product_price','$total_price','".$_SESSION['mcw_id']."', '$name','$email','$phone','$scity','$saddress','$szip','ordered' , '".date("d-m-Y")."', '".date("Y-m-d")."')";
              $insert= mysqli_query($conn,$query);
        
     if($insert){ 
         
         unset($_SESSION["cart_item"]);
     unset($_SESSION['user_id']);
     
         header("Location: order-complete.php?order_number=".$order_number);exit(); }
        }
      }
      
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title -->
     <title>MCW - Mega Computer World</title>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="author" content="spacingtech_webify">
    <!-- favicon -->
    <link rel="shortcut icon" type="image/favicon" href="image/mcw_r.jpeg">
    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- simple-line icon -->
    <link rel="stylesheet" type="text/css" href="css/simple-line-icons.css">
    <!-- font-awesome icon -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="css/themify-icons.css">
    <!-- ion icon -->
    <link rel="stylesheet" type="text/css" href="css/ionicons.min.css">
    <!-- owl slider -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <!-- swiper -->
    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
    <!-- animation -->
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <!-- style -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body class="home-1">
  <?php include "header.php";  ?>
        
  <!-- breadcrumb start -->
        <section class="about-breadcrumb">
            <div class="about-back section-tb-padding" style="background-image: url(image/about-image.jpg)">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="about-l">
                                <ul class="about-link">
                                    <li class="go-home"><a href="index1.html">Home</a></li>
                                    <li class="about-p"><span>Your checkout</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb end -->
        <!-- checkout page start -->
        <section class="section-tb-padding">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="checkout-area">
                            <div class="billing-area">
                                <form method="POST" action="">
                                    <h2>Billing details</h2>
                                    <div class="billing-form">
                                        <p><?php if(isset($error)) {
                                               echo '<p style="color:red;">'. $error .'</p>';
                                              }?></p>
                                        <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Full name</label>
                                                <input type="text" name="name" value="<?php  if(isset($_SESSION['mcw_username'])) { echo $_SESSION['mcw_username'];  } ?>" placeholder="First name">
                                            </li>
                                        </ul>
                                         <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Email address</label>
                                                <input type="text" name="email" value="<?php  if(isset($_SESSION['mcw_useremail'])) { echo $_SESSION['mcw_useremail'];  } ?>" placeholder="Email address">
                                            </li>
                                             </ul>
                                         <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Phone</label>
                                                <input type="text" value="<?php  if(isset($_SESSION['mcw_mobile'])) { echo $_SESSION['mcw_mobile'];  } ?>" name="phone" placeholder="Phone">
                                            </li>
                                        </ul>
                                        <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Town / City</label>
                                                <input type="text" name="city" value="<?php  if(isset($_SESSION['mcw_city'])) { echo $_SESSION['mcw_city'];  } ?>" placeholder="Town / City">
                                            </li>
                                        </ul>
                                        <ul class="billing-ul">
                                            <li class="comment-area">
                                                <label>Address</label>
                                                <textarea name="address" rows="2" placeholder="Address" cols="80"><?php  if(isset($_SESSION['mcw_address'])) { echo $_SESSION['mcw_address'];  } ?></textarea>
                                            </li>
                                        </ul>
                                        <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Postcode / ZIP</label>
                                                <input type="text" name="zip" value="<?php  if(isset($_SESSION['mcw_pin'])) { echo $_SESSION['mcw_pin'];  } ?>" placeholder="Town / City">
                                            </li>
                                        </ul>
                                       <ul class="shipping-form">
                                           <br>
                                           <h2>Shipping details</h2>
                                            <br><li class="check-box">
                                                <input type="checkbox"  name="billingtoo" onclick="FillBilling(this.form)">
                                                <label for="billingtoo">Ship to a different address?</label>
                                            </li> </ul>
                                             <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Town / City</label>
                                                <input type="text" name="scity" placeholder="Shipping Town / City">
                                            </li>
                                        </ul>
                                        <ul class="billing-ul">
                                            <li class="comment-area">
                                                <label>Address</label>
                                                <textarea name="saddress" rows="2" placeholder="Shipping Address" cols="80"></textarea>
                                            </li>
                                        </ul>
                                        <ul class="billing-ul">
                                            <li class="billing-li">
                                                <label>Postcode / ZIP</label>
                                                <input type="text" name="szip" placeholder="Shipping Postcode / ZIP">
                                            </li>
                                        </ul>
                                    </div>
                                
                            </div>
                             <?php
                                    if(isset($_SESSION["cart_item"])){
                                        $total_quantity = 0;
                                        $total_price = 0;  

                                  ?>
                            <div class="order-area">
                                <div class="check-pro">
                                    <h2>In your cart (<?php echo $total_quantitys; ?>)</h2>
                                    <ul class="check-ul">
                                         <?php      foreach ($_SESSION["cart_item"] as $item){
                                         $item_price = $item["quantity"]*$item["sell_price"];
                                        ?>
                                        <li>
                                            <div class="check-pro-img">
                                                <a href="product-details.php?p_id=<?php echo $item["p_id"]; ?>"><img src="admin/products/<?php echo $item["img1"]; ?>" class="img-fluid" alt="image"></a>
                                            </div>
                                            <div class="check-content">
                                                <a href="product.html"><?php echo $item["name"]; ?></a>
                                                <span class="check-code-blod"> Quantity : <span><?php echo $item["quantity"]; ?></span></span>
                                                <span class="check-price"><?php echo "₹ ". number_format($item_price,2); ?></span>
                                            </div>
                                        </li>
                                         <?php   
                                           $total_quantity += $item["quantity"];
                                        $total_price += ($item["sell_price"]*$item["quantity"]);
                                        }    ?>
                                          <?php    } else {     ?>
                                         <div class="row">
                                                      <div class="col-xs-12 col-sm-12">
                                                           <strong class="product-name text-center">Your Cart is Empty</strong>
                                                      </div>
                                                   
                                                    </div>
                                        <?php  }    ?>
                                    </ul>
                                </div>
                                <h2>Your order</h2>
                                <ul class="order-history">
                                    <li class="order-details">
                                        <span>CART SUBTOTAL :</span>
                                        <span><?php if (isset($total_price)){echo "₹ ".number_format($total_price, 2); }else {echo "₹ 0.00";}?></span>
                                    </li>
                                    <li class="order-details">
                                        <span>SHIPPING :</span>
                                        <span>Free shipping</span>
                                    </li>
                                    <li class="order-details">
                                        <span>ORDER TOTAL :</span>
                                        <span><?php if (isset($total_price)){echo "₹ ".number_format($total_price, 2); }else {echo "₹ 0.00";}?></span>
                                    </li>
                                    <!--<li class="order-details">-->
                                    <!--    <span>Total:</span>-->
                                    <!--    <span>$323.00</span>-->
                                    <!--</li>-->
                                </ul>
                                <div class="checkout-btn">
                                    <button type="submit" name="checkout" class="btn-style1">Place order</button>
                                </div>
                            </div>
                        </div>
                      </form>
                    </div>
                </div>
            </div>
        </section>
    <!-- footer start -->
    <?php include "footer.php";  ?>
   
    <a href="javascript:void(0)" class="scroll" id="top">
        <span><i class="fa fa-angle-double-up"></i></span>
    </a>
    <!-- back to top end -->
    <div class="mm-fullscreen-bg"></div>
    <!-- jquery -->
    <script src="js/modernizr-2.8.3.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- popper -->
    <script src="js/popper.min.js"></script>
    <!-- fontawesome -->
    <script src="js/fontawesome.min.js"></script>
    <!-- owl carousal -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- swiper -->
    <script src="js/swiper.min.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>
      <script>

</script>
</body>
</html>