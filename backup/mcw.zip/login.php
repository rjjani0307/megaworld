<?php
include "db.php";
session_start();

if(isset($_POST["login_mcw"]))   
{  
  $email = $_POST["email"];
  $password = $_POST["password"];

  $sql = "Select * from users where o_email = '" . $email . "' and pwd = '" . $password . "'";
  $result = mysqli_query($conn,$sql);  
 $user = mysqli_fetch_array($result); 
  if($user)   
  {   
      $_SESSION["mcw_useremail"] = $email;
      $_SESSION["mcw_username"] = $user['fullname'];
     $_SESSION["mcw_id"] = $user['user_id'];
       $_SESSION["mcw_mobile"] = $user['mobile'];
      $_SESSION["mcw_pan"] = $user['pan'];
      $_SESSION["mcw_gst"] = $user['gst'];
      $_SESSION["mcw_address"] = $user['add1'];
      $_SESSION["mcw_pin"] = $user['pin'];
      $_SESSION["mcw_city"] = $user['city'];
      

   if(!empty($_POST["remember"]))   
   {  
      setcookie ("mcw_emailid",$email,time()+ (10 * 365 * 24 * 60 * 60));  
      setcookie ("mcw_passwordid",$password,time()+ (10 * 365 * 24 * 60 * 60)); 
   }  
   else  
   {  
    if(isset($_COOKIE["mcw_emailid"]))   
    {  
     setcookie ("mcw_emailid","");  
    }  
    if(isset($_COOKIE["mcw_passwordid"]))   
    {  
     setcookie ("mcw_passwordid","");  
    }  
   }  
   header("location:index.php"); 
  }  
  else  
  {  
   $message = "Invalid Login";  
  } 
 
} 

     //forgot password 

  if(isset($_POST['forget_pwd'])){
    
  $forgot_email = $_POST["forgot_email"];
    $sql = "Select o_email,pwd,fullname from users where o_email = '" . $forgot_email . "'";
      $result = mysqli_query($conn,$sql);  
         $user = mysqli_fetch_array($result); 
  if($user)   
  {  
      $email = $user['o_email'];
      $name = $user['fullname'];
      $pwd = uniqid();
      
      $query = "UPDATE `users` SET `pwd`= '$pwd' WHERE o_email = '" . $email . "'";
     $exec= mysqli_query($conn,$query);
  if ($exec) {
  
        
     /* $actual_link = "http://www.domain.com/login.php";
      $toEmail = $forgot_email;
      $subject = "Forget Password Email";
      $content = '';
            $headers .= 'From: <info@domain.com>' . "\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
      if(mail($toEmail, $subject, $content, $headers)) {  } */

      ?> <script>alert('Forget Password Mail Sent Please Check Your Email');
          window.location="login.php";</script> <?php
  
      unset($_POST);
  }
 }
 else{   
       ?>   <script>alert('Email ID Incorrect');
        window.location="login.php";</script>   <?php
   }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title -->
     <title>MCW - Mega Computer World</title>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="author" content="spacingtech_webify">
    <!-- favicon -->
    <link rel="shortcut icon" type="image/favicon" href="image/mcw_r.jpeg">
    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- simple-line icon -->
    <link rel="stylesheet" type="text/css" href="css/simple-line-icons.css">
    <!-- font-awesome icon -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="css/themify-icons.css">
    <!-- ion icon -->
    <link rel="stylesheet" type="text/css" href="css/ionicons.min.css">
    <!-- owl slider -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <!-- swiper -->
    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
    <!-- animation -->
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <!-- style -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body class="home-1">
  <?php include "header.php";  ?>
        
    <!-- breadcrumb start -->
        <section class="section-b-padding" style="background-color: #f2f2f2">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="login-area">
                        <div class="login-box">
                            <h1>Login</h1>
                            <form action="" method ="POST">
                                
                  <label for="email">Email Address</label>
                   <input type="email" placeholder="Username or email address" name="email" class="input"  value="<?php if(isset($_COOKIE["mcw_emailid"])) { echo $_COOKIE["mcw_emailid"]; } ?>" required />
             
                   <label for="password">Password</label>
                <input type="password" name="password" placeholder="Password" class="input"  value="<?php if(isset($_COOKIE["mcw_passwordid"])) { echo $_COOKIE["mcw_passwordid"]; } ?>" required />   

               <?php if(isset($message)){ echo "<span style='color: red;'>".$message."</span>"; }  ?>


               <input type="checkbox" name="remember" style="width: 10%;" id="remember" <?php 
               if(isset($_COOKIE["mcw_emailid"])) { ?> checked <?php } ?>>
               <label for="remember">&nbsp; Remember Me</label>
               <br><br>
                <button type="submit" class="btn-style1" name="login_mcw" >Sign in</button>
                                
                                
                                <a href="javascript:void(0)"  class="re-password" data-bs-toggle="modal" data-bs-target="#forgotModal">Forgot your password ?</a>
                            </form>
                        </div>
                        <div class="login-account">
                            <h4>Don't have an account?</h4>
                            <a href="register.php" class="ceate-a">Create account</a>
                            <div class="login-info">
                                <a href="terms-conditions.html" class="terms-link"><span>*</span> Terms & conditions.</a>
                                <p>Your privacy and security are important to us. For more information on how we use your data read our <a href="privacy-policy.html">privacy policy</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- login end -->
      <section class="quick-view">
        <div class="modal fade vegist-popup" id="forgotModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="popup-content">
                            <!-- popup close button start -->
                            <a href="javascript:void(0)" data-bs-dismiss="modal" aria-label="Close" class="close-btn"><i class="ion-close-round"></i></a>
                            <!-- popup close button end -->
                            <!-- popup content area start -->
                            <div class="pop-up-newsletter" style="background-image: url(image/news-popup.jpg5);">
                                <div class="logo-content">
                                    <a href="index1.html"><img src="image/mcw_r.jpeg" alt="image" class="img-fluid"></a>
                                    <h4>Forgot Password</h4>
                                    <span>Enter Email to get the new password</span>
                                </div>
                                <form action="" method="POST">
                                <div class="subscribe-area">
                                    <input type="email" name="forgot_email" placeholder="Enter your email address" required="">
                                    <button type="submit" style="margin-top: 20px" name="forget_pwd" class="btn btn-style1">Reset</button>
                                </div>
                              </form>
                            </div>
                            <!-- popup content area end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- footer start -->
    <?php include "footer.php";  ?>
   
    <a href="javascript:void(0)" class="scroll" id="top">
        <span><i class="fa fa-angle-double-up"></i></span>
    </a>
    <!-- back to top end -->
    <div class="mm-fullscreen-bg"></div>
    <!-- jquery -->
    <script src="js/modernizr-2.8.3.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- popper -->
    <script src="js/popper.min.js"></script>
    <!-- fontawesome -->
    <script src="js/fontawesome.min.js"></script>
    <!-- owl carousal -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- swiper -->
    <script src="js/swiper.min.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>
</body>
</html>