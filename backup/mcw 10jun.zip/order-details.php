<?php
  include "addtocart.php";
  include "db.php";

if (!isset($_SESSION['mcw_useremail'])) { header("location:login.php");  }


if (isset($_GET["ord_no"])) {

  $sql = "SELECT * FROM `order` where order_number ='" . $_GET["ord_no"] . "'";
      $result = $conn->query($sql);
      $row = $result->fetch_assoc();

 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title -->
     <title>MCW - Mega Computer World</title>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="author" content="spacingtech_webify">
    <!-- favicon -->
    <link rel="shortcut icon" type="image/favicon" href="image/mcw_r.jpeg">
    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- simple-line icon -->
    <link rel="stylesheet" type="text/css" href="css/simple-line-icons.css">
    <!-- font-awesome icon -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="css/themify-icons.css">
    <!-- ion icon -->
    <link rel="stylesheet" type="text/css" href="css/ionicons.min.css">
    <!-- owl slider -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <!-- swiper -->
    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
    <!-- animation -->
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <!-- style -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body class="home-1">
  <?php include "header.php";  ?>
      
       <section class="section-tb-padding">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="order-area">
                        <div class="order-price">
                            <ul class="total-order">
                                <li>
                                    <span class="order-no">Order no. <?php echo $row['order_number']; ?></span>
                                    <span class="order-date"><?php echo $row['ord_date']; ?></span>
                                </li>
                                <li>
                                    <span class="total-price">Order total</span>
                                    <span class="amount"> <?php if (isset($row['total_amount'])){echo "₹ ".number_format($row['total_amount'], 2); }else {echo "₹ 0.00";}?></span>
                                </li>
                            </ul>
                        </div>
                        
                        <div class="order-delivery">
                            <ul class="delivery-payment">
                                <li class="delivery">
                                    <h5>Delivery address</h5>
                                    <p><?php echo $row['user_name']; ?></p>
                                    <span class="order-span"><?php echo nl2br($row['address']); ?></span>
                                    <span class="order-span"><?php echo $row['city'] . " - " . $row['zip']; ?></span>
                                    <span class="order-span">Email : <?php echo $row['email']; ?></span>
                                    <span class="order-span">Mobile No : <?php echo $row['number']; ?></span>
                                </li>
                                <li class="pay">
                                    <h5>Payment summary</h5>
                                    <!--<p class="transition">Transaction No : 66282856617</p>-->
                                    <span class="order-span p-label">
                                        <span class="n-price">Price</span>
                                        <span class="o-price"> <?php if (isset($row['total_amount'])){echo "₹ ".number_format($row['total_amount'], 2); }else {echo "₹ 0.00";}?></span>
                                    </span>
                                    <span class="order-span p-label">
                                        <span class="n-price">Shipping charge</span>
                                        <span class="o-price">Free</span>
                                    </span>
                                    <span class="order-span p-label">
                                        <span class="n-price">Order Total</span>
                                        <span class="o-price"> <?php if (isset($row['total_amount'])){echo "₹ ".number_format($row['total_amount'], 2); }else {echo "₹ 0.00";}?></span>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>  
   
    <!-- footer start -->
    <?php include "footer.php";  ?>
   
    <a href="javascript:void(0)" class="scroll" id="top">
        <span><i class="fa fa-angle-double-up"></i></span>
    </a>
    <!-- back to top end -->
    <div class="mm-fullscreen-bg"></div>
    <!-- jquery -->
    <script src="js/modernizr-2.8.3.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- popper -->
    <script src="js/popper.min.js"></script>
    <!-- fontawesome -->
    <script src="js/fontawesome.min.js"></script>
    <!-- owl carousal -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- swiper -->
    <script src="js/swiper.min.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>
</body>
</html>
<?php  }else{

      header("location:index.php");

} ?>