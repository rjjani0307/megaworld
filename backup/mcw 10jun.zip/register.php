<?php
include "db.php";
session_start();

if(isset($_POST["register"]))   
{  

  $name = $_POST["name"];
  $org = $_POST["org"];
  $gst = $_POST["gst"];
  $pan = $_POST["pan"];
  $add1 = $_POST["add1"];
  $add2 = $_POST["add2"];
  $city = $_POST["city"];
  $pin = $_POST["pin"];
  $state = $_POST["state"];
  $country = $_POST["country"];
  $c_number = $_POST["c_number"];
  $mobile = $_POST["mobile"];
  $email = $_POST["email"];
  $c_name = $_POST["c_name"]; 
  $fullname = $_POST["fullname"];
  $address = $_POST["address"];
  $o_number = $_POST["o_number"];
  $o_email = $_POST["o_email"];
  $pwd = $_POST["pwd"];
  $c_pwd = $_POST["c_pwd"];

    $username = strstr($_POST['name'], ' ', true);
    $user_id = strtoupper($username . rand(10000,99999));

     if($pwd == $pwd) {

         $query = " INSERT INTO `users`(`user_id`, `name`, `org`, `gst`, `pan`, `add1`, `add2`, `city`, `pin`, `state`, `country`, `c_number`, `mobile`, `email`, `c_name`, `fullname`, `address`, `o_number`, `o_email`, `pwd`) VALUES ('$user_id', $name', '$org', '$gst', '$pan', '$add1', '$add2', '$city', '$pin', '$state', '$country', '$c_number', '$mobile', '$email', '$c_name', '$fullname', '$address', '$o_number', '$o_email', '$pwd')";

        $exec= mysqli_query($conn,$query);
        if ($exec) {

        /*  $actual_link = "http://www.domain.com/login.php";
          $toEmail = $o_email;
          $subject = "User Registration Email";
          $content = '';
         $headers .= 'From: <info@domain.com>' . "\r\n";
         $headers .= "MIME-Version: 1.0\r\n";
         $headers .= "Content-Type: text/html; charset=UTF-8\r\n";


        if(mail($toEmail, $subject, $content, $headers)) {
                                                      }*/
             ?> <script>alert('User Registered Successfully');
                 window.location= "login.php";</script> <?php
         }else{  
             $error = "Email is Alredy Registered !"; 
              }
                }else{
                   $error = "<br>Password & Confirm Password Are Not Same !"; 
                     }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- title -->
     <title>MCW - Mega Computer World</title>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="author" content="spacingtech_webify">
    <!-- favicon -->
    <link rel="shortcut icon" type="image/favicon" href="image/mcw_r.jpeg">
    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- simple-line icon -->
    <link rel="stylesheet" type="text/css" href="css/simple-line-icons.css">
    <!-- font-awesome icon -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="css/themify-icons.css">
    <!-- ion icon -->
    <link rel="stylesheet" type="text/css" href="css/ionicons.min.css">
    <!-- owl slider -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
    <!-- swiper -->
    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
    <!-- animation -->
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <!-- style -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <style>
    .error{
        outline: 1px solid red;
    }
    .canceled {
      color: red;
    }
</style>
</head>
<body class="home-1">
  <?php include "header.php";  ?>
        
   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function(){
    $('#myForm input[type="text"], input[type="email"], input[type="number"], input[type="password"], textarea, select').blur(function(){
        if(!$(this).val()){
            $(this).addClass("error");
        } else{
            $(this).removeClass("error");
        }
    });
});
</script>
      <section class="contact section-tb-padding" style="background-color: #f2f2f2">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="map-area">
                           <div class="map-title">
                                <h1>Registration</h1>
                            </div>
                           
                            <div class="map-details">
                                <div class="contact-info" style="width: 100%;">
                                    <div class="text-danger"><?php if(isset($error)) { echo $error; } ?></div>
                                    <div class="contact-details">
                                        <h4>Firm/Company information</h4>
                                        <form method="POST" action="" id="myForm">
                                            <div class="row">
                                             <div class="col-md-6">
                                            <label>Firm Company Name <span class="canceled">*</span></label>
                                                 <input type="text" name="name" placeholder="Firm Company name" required=""/>
                                             <label>Organization  <span class="canceled">*</span></label>
                                            <select name="org"  style="width: 100%;" required>
                                                 <option>Choose Your Organization </option>
                                                <option value="Proprietorship">Proprietorship</option>
                                                <option value="Partnership">Partnership</option>
                                                <option value="LLP">LLP</option>
                                                <option value="Private Limited">Private Limited</option>
                                                <option value="Limited">Limited</option>
                                            </select>   
                                            <label>GST Number   <span class="canceled">*</span></label>
                                                 <input type="text" name="gst" placeholder="GST Number" required="">
                                            <label>PAN Number  <span class="canceled">*</span></label>
                                                 <input type="text" name="pan" placeholder="PAN Number" required="">
                                            <label>Business Address 1  <span class="canceled">*</span></label>
                                                 <textarea name="add1" rows="3" placeholder="Business Address 1" required=""></textarea>
                                            <label>Business Address 2 <span class="canceled">*</span></label>
                                                 <textarea name="add2" rows="3" placeholder="Business Address 2" required=""></textarea>
                                            <label>City <span class="canceled">*</span></label>
                                                 <input type="text" name="city" placeholder="City" required="">
                                            <label>Pincode <span class="canceled">*</span></label>
                                                 <input type="text" name="pin" placeholder="Pincode" required="">
                                            <label>State <span class="canceled">*</span></label>
                                                 <input type="text" name="state" placeholder="State" required="">
                                            <label>Country <span class="canceled">*</span></label>
                                                  <input type="text" name="country" placeholder="Country" required="">
                                            </div>
                                            <div class="col-md-6">
                                            <label>Company Number</label>
                                                 <input type="text" name="c_number" placeholder="Company number" >
                                            <label>Mobile Number <span class="canceled">*</span></label>
                                                 <input type="number" name="mobile" placeholder="Mobile Number" required="">
                                            <label>Email ID <span class="canceled">*</span></label>
                                                 <input type="email" name="email" placeholder="Email ID" required="">

                                            <h4 style="margin-top: 35px">Owner Information</h4>
                                            <label>Company Name</label>
                                                 <input type="text" name="c_name" placeholder="Company Name">
                                            <label>Full Name <span class="canceled">*</span></label>
                                                 <input type="text" name="fullname" placeholder="Full Name" required="">
                                            <label>Address <span class="canceled">*</span></label>
                                                 <textarea name="address" rows="2" placeholder="Address" required=""></textarea>
                                            <label>Mobile Number <span class="canceled">*</span></label>
                                                 <input type="text" name="o_number" placeholder="Mobile Number" required="">
                                            <label>Email Id <span class="canceled">*</span> </label>
                                                 <input type="email" name="o_email" placeholder="Email Id" required="">
                                            <label>New Password <span class="canceled">*</span></label>
                                                 <input type="password" name="pwd" id="new_pwd" placeholder="New password" required="">
                                            <label>Confirm Password <span class="canceled">*</span></label>
                                                 <input type="text" name="c_pwd" id="re_pwd" placeholder="Confirm password" required="">
                                                 <span id='message'></span>
                                             </div>  
                                              </div>
                                            <button type="Submit" name="register" class="btn-style1" style="margin-top: 20px; float: right;">Submit <i class="ti-arrow-right"></i></button>  
                                         </form>
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <!-- login end -->
    <!-- footer start -->
    <?php include "footer.php";  ?>
    <!-- footer copyright end -->
    <!-- back to top start -->
    <a href="javascript:void(0)" class="scroll" id="top">
        <span><i class="fa fa-angle-double-up"></i></span>
    </a>
    <!-- back to top end -->
    <div class="mm-fullscreen-bg"></div>
    <!-- jquery -->
    <script src="js/modernizr-2.8.3.min.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- popper -->
    <script src="js/popper.min.js"></script>
    <!-- fontawesome -->
    <script src="js/fontawesome.min.js"></script>
    <!-- owl carousal -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- swiper -->
    <script src="js/swiper.min.js"></script>
    <!-- custom -->
    <script src="js/custom.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
  // Password Matching
  $('#new_pwd, #re_pwd').on('keyup', function () {
    if ($('#new_pwd').val() == '' && $('#re_pwd').val() == '') { 
       $('#message').html('Fill Passwords Fields').css('color', 'red');
    } else
    if ($('#new_pwd').val() == $('#re_pwd').val() && $('#new_pwd').val() != '' && $('#re_pwd').val() != '') {
        $('#message').html('Password Are Matched').css('color', 'green');
    } else 
        $('#message').html('Passwords Are Not Matching').css('color', 'red');
    });
  </script>
</body>
</html>