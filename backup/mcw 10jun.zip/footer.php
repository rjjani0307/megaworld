 <!-- footer start -->
        <section class="footer-one section-tb-padding">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="footer-service">
                          <h6>Before buying any laptop accessories, please re-confirm compatibility.</h6>
                        </div>
                        <div class="f-logo">
                            <ul class="footer-ul">
                                <li class="footer-li footer-logo">
                                    <a href="index1.html">
                                        <img class="img-fluid" src="image/mcw_name.jpeg" width="200" alt="">
                                    </a>
                                </li>
                                <li class="footer-li footer-address">
                                    <ul class="f-ul-li-ul">
                                        <li class="footer-icon">
                                            <i class="ion-ios-location"></i>
                                        </li>
                                        <li class="footer-info">
                                            <h6>Address</h6>
                                            <span>B/1, Basement, APM shopping complex,</span> 
                                            <span></span>
                                            <span>Opposite SUN N STEP CLUB,</span>
                                            <span>near Sattadhar Char Rasta,</span>
                                            <span> Ahmedabad APM complex, - 380061.</span>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer-li footer-contact">
                                    <ul class="f-ul-li-ul">
                                        <li class="footer-icon">
                                            <i class="ion-ios-telephone"></i>
                                        </li>
                                        <li class="footer-info">
                                            <h6>Contact</h6>
                                            <a href="tel:+91 8160582238">Phone: +91 8160582238</a>
                                            <a href="mailto:megacompuworld1@gmail.com">Email: megacompuworld1@gmail.com</a>
                                            <a href="mailto:mega.compuworld@yahoo.com"> mega.compuworld@yahoo.com</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer-li footer-address">
                                    <ul class="f-ul-li-ul">
                                        <li class="footer-icon">
                                            <i class="ion-ios-briefcase"></i>
                                        </li>
                                        <li class="footer-info">
                                            <h6>Bank Account</h6>
                                            <span><b> Account Name:</b><br> MEGA COMPU WORLD</span>
                                            <span><b>BOI Acc. number:</b> <br>204820110000683</span>
                                            <span><b>IFSC NO:</b> BKIDO002048</span>
                                            <span><b>Branch: </b>GURUKUL (AHMEDABAD)</span>
                                          
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="footer-bottom section-t-padding">
                            <div class="footer-link" id="footer-accordian">
                                <div class="f-link">
                                    <h2 class="h-footer">Information</h2>
                                    <a href="#t-cate" data-bs-toggle="collapse" class="h-footer">
                                        <span>Information</span>
                                        <i class="fa fa-angle-down"></i>
                                    </a>
                                    <ul class="f-link-ul collapse" id="t-cate" data-bs-parent="#footer-accordian">
                                        <li class="f-link-ul-li"><a href="about-us.php">About Us</a></li>
                                        <li class="f-link-ul-li"><a href="shipping-information.php">Shipping Information</a></li>
                                        <li class="f-link-ul-li"><a href="privacy-policy.php">Privacy Policy</a></li>
                                        <li class="f-link-ul-li"><a href="terms-conditions.php">Terms & Conditions</a></li>
                                    </ul>
                                </div>
                                <div class="f-link">
                                    <h2 class="h-footer">Customer Service</h2>
                                    <a href="#services" data-bs-toggle="collapse" class="h-footer">
                                        <span>Customer Service</span>
                                        <i class="fa fa-angle-down"></i>
                                    </a>
                                    <ul class="f-link-ul collapse" id="services" data-bs-parent="#footer-accordian">
                                        <li class="f-link-ul-li"><a href="contact-us.php">Contact Us</a></li>
                                        <li class="f-link-ul-li"><a href="faq%27s.html">Service Centre list</a></li> 
                                        <li class="f-link-ul-li"><a href="payment-policy.html">Account</a></li>
                                        <li class="f-link-ul-li"><a href="privacy-policy.html">Order History</a></li>
                                        <li class="f-link-ul-li"><a href="return-policy.html">Wishlist</a></li>
                                    </ul>
                                </div>
                                <div class="f-link" style="width: calc(50% - 30px);">
                                    <h2 class="h-footer">Contact Details</h2>
                                    <a href="#privacy" data-bs-toggle="collapse" class="h-footer">
                                        <span>Contact Details</span>
                                        <i class="fa fa-angle-down"></i>
                                    </a>
                                    <ul class="f-link-ul collapse" id="privacy" data-bs-parent="#footer-accordian">
                                        <li class="f-link-ul-li">Sales Ahmedabad : 9924149647</li>
                                        <li class="f-link-ul-li">Sales Gujrat : 9924149647/9979530254/ 9904004519</li>
                                        <li class="f-link-ul-li">Sales India : 8160582238</li>
                                         <li class="f-link-ul-li">Sales Laptop Accessories : 9979530254/9904004519/ 9038559714</li>
                                          <li class="f-link-ul-li">Dispatch : 9724639546/9998212053 </li>
                                           <li class="f-link-ul-li">RMA Replacement : 9714602500</li>
                                            <li class="f-link-ul-li">Account : 9727472874/8511767184 </li>
                                             <li class="f-link-ul-li">Complain & Suggestion : 9471282449/8160582238</li>
                                    </ul>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- footer end -->
        <!-- footer copyright start -->
        <section class="footer-copyright">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <ul class="f-bottom">
                            <li class="f-c f-copyright">
                                <p>Copyright <i class="fa fa-copyright"></i> 2021 spacingtech</p>
                            </li>
                            <li class="f-c f-social">
                                <a href="https://www.whatsapp.com/" class="f-icn-link"><i class="fa fa-whatsapp"></i></a>
                                <a href="https://www.facebook.com/" class="f-icn-link"><i class="fa fa-facebook-f"></i></a>
                                <a href="https://twitter.com/" class="f-icn-link"><i class="fa fa-twitter"></i></a>
                                <a href="https://www.instagram.com/" class="f-icn-link"><i class="fa fa-instagram"></i></a>
                                <a href="https://www.pinterest.com/" class="f-icn-link"><i class="fa fa-pinterest-p"></i></a>
                                <a href="https://www.youtube.com/" class="f-icn-link"><i class="fa fa-youtube"></i></a>
                            </li>
                            <li class="f-c f-payment">
                                <a href="checkout-1.html"><img src="image/payment.png" class="img-fluid" alt="payment image"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- footer copyright end -->